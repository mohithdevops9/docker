Simple Maven Project
